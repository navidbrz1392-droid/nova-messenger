# NOVA Messenger — MVP starter

This is a runnable starter for the first NOVA milestone: account registration/login, user search, direct conversations, persistent text messages, and real-time delivery.

## Requirements
- Node.js 20+
- Docker Desktop (or a local PostgreSQL 16 instance)

## Run locally
1. Copy `.env.example` to `.env`.
2. Replace `JWT_SECRET` with a random secret of at least 32 characters.
3. Start PostgreSQL: `docker compose up -d`.
4. Install dependencies: `npm install`.
5. Start NOVA: `npm start`.
6. Open http://localhost:3000 in two browser profiles and create two accounts to test messaging.

## Included
- Express API and Socket.IO real-time gateway
- PostgreSQL schema for users, conversations, memberships and messages
- Password hashing with bcrypt
- JWT-protected REST and socket connections
- Basic rate limiting, request size limit and Helmet security headers
- Responsive starter web UI

## Important: not production-ready yet
Before public launch, implement and test:
- Email verification, password reset, session revocation and stronger abuse controls
- HTTPS, managed secrets, database backups, migrations and monitoring
- Block/report flows, moderation queue, spam detection and age-appropriate safety controls
- Private file upload pipeline with malware scanning and access controls
- Push notifications
- WebRTC signaling plus TURN infrastructure for calls
- End-to-end encryption with a reviewed protocol and independent security review
- Privacy policy, terms, data retention/deletion controls and applicable legal compliance
- Automated tests, load tests, accessibility and deployment pipeline

Do not expose the development database or use the example credentials in production.
